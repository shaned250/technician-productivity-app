# Technician Productivity App

This is the full project package including backend, mobile app, manager dashboard, and database.
