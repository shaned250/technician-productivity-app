// React Native App.js starter
